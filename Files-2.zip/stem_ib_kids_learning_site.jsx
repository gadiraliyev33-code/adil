import React, { useState, useMemo } from 'react';

export default function STEMIBSite(){
const modules={
'Science Lab':{tasks:['Build a volcano model','Observe plant growth for 7 days','Make a water filtration system'],materials:['Cambridge Primary Science: states of matter, forces, plants, habitats','NGSS aligned experiments: observation, hypothesis, variables, data tables','IB inquiry worksheet: ask, investigate, reflect']},
'Math Mission':{tasks:['Solve 10 fractions questions','Geometry shape hunt','Create a budget plan'],materials:['Singapore Math methods: number sense, fractions, bar models','Cambridge Math practice: geometry, measurement, statistics','IB problem solving guide: reasoning, patterns, reflection']},
'Coding Corner':{tasks:['Create a calculator','Build a quiz app','Learn loops challenge'],materials:['Scratch lessons: sprites, loops, events, variables','Python basics: input/output, conditions, loops, functions','Computational thinking puzzles: logic, debugging, sequencing']},
'Robotics Zone':{tasks:['Design a robot arm','Sensor challenge','Maze robot logic'],materials:['Robotics guide: Sensors detect light, distance, touch and sound. Motors create movement. Gears change speed and force. Design cycle = ask, imagine, plan, create, test, improve.','Arduino basics: Learn circuits using battery power, resistors, breadboard wiring, LEDs, buttons and buzzers. Write simple code to blink LEDs, read buttons and control devices.','Engineering journal: Record idea sketches, materials used, prototype photos, test results, problems found, improvements made and final reflection.']},
'Reading & Reflection':{tasks:['Read 20 mins daily','Write reflection paragraph','Summarize a story'],materials:['International reading list: fiction, nonfiction, biographies','Journal template: claim, evidence, reflection','Vocabulary builder: roots, context clues, synonyms']},
'Projects Portfolio':{tasks:['Make solar system model','Create business idea poster','Community service plan'],materials:['Project planner: research question, timeline, milestones','Presentation template: slides, speaking notes, visuals','Creativity rubric: originality, usefulness, communication']}
};
const [selected,setSelected]=useState(null);
const [answers,setAnswers]=useState({});
const [openMaterial,setOpenMaterial]=useState(null);
const [timeSpent,setTimeSpent]=useState({});
const sessionStart=React.useRef(Date.now());

React.useEffect(()=>{
if(selected){sessionStart.current=Date.now();}
return ()=>{
if(selected){
const diff=Math.floor((Date.now()-sessionStart.current)/1000);
setTimeSpent(prev=>({...prev,[selected]:(prev[selected]||0)+diff}));
}
};
},[selected]);
const dailySeed=new Date().toISOString().slice(0,10);
const questionBank={
'Math Mission':[
{q:'What is 12 + 8?',opts:['18','20','22'],a:1},{q:'What is 15 - 7?',opts:['8','7','9'],a:0},{q:'Which is half of 24?',opts:['10','12','14'],a:1},{q:'How many sides has a hexagon?',opts:['5','6','7'],a:1},{q:'What is 6 x 4?',opts:['24','20','26'],a:0},{q:'What is 36 ÷ 6?',opts:['5','6','7'],a:1},{q:'Which is biggest?',opts:['0.9','0.5','0.2'],a:0}],
'Science Lab':[
{q:'Which planet is known as the Red Planet?',opts:['Mars','Venus','Jupiter'],a:0},{q:'Water becomes gas by?',opts:['Freezing','Evaporation','Melting'],a:1},{q:'Plants make food using?',opts:['Photosynthesis','Gravity','Rust'],a:0},{q:'Which is a mammal?',opts:['Shark','Dolphin','Lizard'],a:1},{q:'Force that pulls objects down?',opts:['Magnetism','Gravity','Light'],a:1},{q:'Which organ pumps blood?',opts:['Lung','Heart','Kidney'],a:1},{q:'Which is renewable?',opts:['Solar','Coal','Oil'],a:0}],
'Coding Corner':[
{q:'Which repeats instructions?',opts:['Loop','Screen','Mouse'],a:0},{q:'Which stores value?',opts:['Variable','Speaker','Cable'],a:0},{q:'Bug in code means?',opts:['Insect','Error','Game'],a:1},{q:'IF statement is for?',opts:['Decision','Music','Drawing'],a:0},{q:'Python is a?',opts:['Language','Robot','Battery'],a:0},{q:'Which finds mistakes?',opts:['Debugging','Painting','Charging'],a:0},{q:'Algorithm means?',opts:['Step plan','Picture','Wire'],a:0}],
'Robotics Zone':[
{q:'Which detects distance?',opts:['Sensor','Wheel','Gear'],a:0},{q:'What creates movement?',opts:['Motor','Paper','Sticker'],a:0},{q:'Gears help change?',opts:['Speed','Color','Sound'],a:0},{q:'Arduino is a?',opts:['Board','Book','Wheel'],a:0},{q:'LED gives?',opts:['Light','Water','Heat'],a:0},{q:'Prototype means?',opts:['First model','Final exam','Battery'],a:0},{q:'Best step after testing?',opts:['Improve','Ignore','Sleep'],a:0}],
'Reading & Reflection':[
{q:'Main idea is?',opts:['Big message','Page number','Cover color'],a:0},{q:'Synonym of happy?',opts:['Sad','Glad','Cold'],a:1},{q:'Biography is about?',opts:['A person life','Animals','Math'],a:0},{q:'Title helps show?',opts:['Topic','Weight','Price'],a:0},{q:'Author is?',opts:['Writer','Reader','Seller'],a:0},{q:'Nonfiction means?',opts:['Real facts','Fairy tale','Poem only'],a:0},{q:'Summary should be?',opts:['Short key points','Whole book copied','Random words'],a:0}],
'Projects Portfolio':[
{q:'First project step?',opts:['Plan','Hide','Sleep'],a:0},{q:'Timeline helps with?',opts:['Schedule','Color','Noise'],a:0},{q:'Research means?',opts:['Find information','Dance','Jump'],a:0},{q:'Prototype is?',opts:['Sample model','Lunch box','Battery'],a:0},{q:'Presentation needs?',opts:['Clear ideas','No voice','Blank slides'],a:0},{q:'Teamwork means?',opts:['Work together','Fight','Ignore'],a:0},{q:'Reflection means?',opts:['Think what learned','Erase work','Run away'],a:0}]
};

const dailyTopics={
robotics:['What is a servo motor and how it controls movement','How sensors are used in self-driving cars','What is a robotic arm and where is it used','Difference between AI robot and normal machine','What is machine learning in simple robotics terms'],
ai:['What is Artificial Intelligence','How AI recognizes images','What is a chatbot and how it works','Difference between AI and human brain','Where AI is used in daily life']
};

const topics365 = [
{t:'Robotics: Sensors',c:'Sensors detect light, distance, and touch. They help robots understand the world.'},
{t:'AI: Machine Learning Basics',c:'Machines learn patterns from data and improve over time.'},
{t:'Robotics: Motors & Movement',c:'Motors convert electrical energy into motion for robots.'},
{t:'AI: Everyday Applications',c:'AI is used in phones, games, maps, and recommendations.'},
{t:'Robotics: Design Cycle',c:'Ask, imagine, plan, build, test, improve is how engineers work.'},
{t:'AI: Chatbots',c:'Chatbots answer questions using trained data models.'},
{t:'Robotics: Robot Arms',c:'Robot arms are used in factories for precision tasks.'}
];

const now=new Date();
const start=new Date(now.getFullYear(),0,0);
const diff=now-start;
const dayOfYear=Math.floor(diff/1000/60/60/24);
const dailyIndex=dayOfYear % 365;

const allDailyLessons=Array.from({length:365},(_,i)=>{
const base=topics365[i%topics365.length];
return {
title:`Day ${i+1}: ${base.t}`,
content:base.c + ' (Level ' + (i<120?'Easy':i<240?'Medium':'Hard') + ')'
};
});

const todaysLesson=allDailyLessons[dailyIndex];
const todaysQuestions=useMemo(()=>selected?questionBank[selected]:[],[selected,dailySeed]);
return (
<div className='min-h-screen p-6 font-sans bg-cover bg-center bg-fixed' style={{backgroundImage:"url(https://images.unsplash.com/photo-1546182990-dffeafbe841d?auto=format&fit=crop&w=1600&q=80)"}}> 
<div className='max-w-6xl mx-auto space-y-6'>
<header className='bg-white/80 backdrop-blur rounded-3xl shadow-2xl p-6 border border-yellow-300'>
<h1 className='text-4xl font-bold'>WELCOME TO YOU NEW WORLD ADIL! GOOD LUCK</h1>

</header>
<section className='grid grid-cols-2 md:grid-cols-3 gap-6 place-items-center'>
{Object.keys(modules).map((x,i)=>(<button key={i} onClick={()=>{setSelected(x);setAnswers({});setOpenMaterial(null);}} className='bg-white/85 backdrop-blur rounded-full shadow-xl w-44 h-44 flex flex-col items-center justify-center text-center hover:scale-105 hover:shadow-2xl transition-all duration-300 border-4 border-amber-200 ring-4 ring-yellow-100'>
<div className='text-4xl mb-2'>{i===0?'🔬':i===1?'➗':i===2?'💻':i===3?'🤖':i===4?'📚':'🚀'}</div><h2 className='text-lg font-bold px-2'>{x}</h2>
<p className='text-xs text-slate-600 mt-1 px-3'>Tap to explore</p>
</button>))}
</section>
{selected && <section className='bg-white/90 backdrop-blur rounded-3xl shadow-2xl p-6 border border-yellow-200'>
<h2 className='text-2xl font-bold'>{selected}</h2>
<h3 className='text-lg font-semibold mt-4'>Tasks to Solve</h3>
<ul className='mt-2 space-y-2 text-slate-700'>{modules[selected].tasks.map((t,i)=><li key={i}>• {t}</li>)}</ul>
<h3 className='text-lg font-semibold mt-5'>Detailed International Materials</h3>
<div className='mt-2 space-y-2 text-slate-700'>{modules[selected].materials.map((m,i)=><div key={i} className='border rounded-xl p-2'><button onClick={()=>setOpenMaterial(openMaterial===i?null:i)} className='w-full text-left font-medium'>📘 Material {i+1} (Click to open)</button>{openMaterial===i && <div className='mt-2 text-sm text-slate-600'>{m}</div>}</div>)}</div>
<h3 className='text-lg font-semibold mt-6'>Daily Quiz (7 Questions • Easy → Difficult)</h3><div className='space-y-4 mt-3'>{todaysQuestions.map((qq,qi)=><div key={qi} className='border rounded-xl p-3'><p className='font-medium'>{qi+1}. {qq.q} <span className='text-xs text-slate-500 ml-2'>{qi<2?'🟢 Easy':qi<5?'🟡 Medium':'🔴 Hard'}</span></p><div className='mt-2 space-y-2'>{qq.opts.map((op,oi)=><button key={oi} disabled={answers[qi]!==undefined} onClick={()=>setAnswers({...answers,[qi]:oi})} className='block w-full text-left border rounded-lg px-3 py-2 disabled:opacity-70'>{op}</button>)}</div>{answers[qi]!==undefined && <p className='mt-2 text-sm font-medium'>{answers[qi]===qq.a ? '✅ Correct Answer' : `❌ Incorrect. Correct answer: ${qq.opts[qq.a]}`}</p>}</div>)}</div></section>}
<section className='bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-2xl p-6 border border-yellow-200'>
<h2 className='text-2xl font-bold'>🤖 Daily Learning Module</h2>
<p className='text-sm mt-2'>One focused topic per day for deep understanding</p>

<div className='mt-4 bg-white/10 rounded-xl p-4'>
<h3 className='text-xl font-semibold'>{todaysLesson.title}</h3>
<p className='text-sm mt-2'>{todaysLesson.content}</p>
</div>

<p className='text-xs mt-3 opacity-80'>This topic changes automatically every day</p>
</section>

<section className='bg-gradient-to-r from-orange-500 to-yellow-500 text-white rounded-2xl p-6 border border-yellow-200'>
<h2 className='text-2xl font-bold'>Parent Dashboard</h2>

<div className='mt-3 space-y-3'>
<h3 className='text-lg font-semibold'>⏱ Time Spent</h3>
<ul className='text-sm'>
{Object.keys(timeSpent).map((m,i)=>(<li key={i}>{m}: {(timeSpent[m]/60).toFixed(1)} minutes</li>))}
</ul>

{selected && (
<div className='mt-4'>
<h3 className='text-lg font-semibold'>📊 Current Quiz Summary ({selected})</h3>
{(() => {
const qs=questionBank[selected];
const correct=Object.keys(answers).filter(k=>answers[k]===qs[k].a).length;
return <p className='text-sm mt-2'>Score: {correct} / {qs.length}</p>;
})()}
</div>
)}

<p className='mt-4 text-sm'>Track learning progress, strengths, and improvement areas over time.</p>
</div>
</section>
</div>
</div>)}
